# pyball-api

The Pyball-API helps get baseball data directly from MLB!